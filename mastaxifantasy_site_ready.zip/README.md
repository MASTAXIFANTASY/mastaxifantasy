# MASTAXIFANTASY
This is the custom fantasy cricket website for live stats, pitch reports, and team predictions.